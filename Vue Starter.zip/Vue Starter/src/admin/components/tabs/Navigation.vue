<template>
    <ul class="tab-menu">
        <li><router-link to="/project-settings">General</router-link></li>
        <li><router-link to="/others">Other</router-link></li>
    </ul>
</template>

<script>
export default {
    name: 'TabNavigation'
}
</script>

<style>

</style>