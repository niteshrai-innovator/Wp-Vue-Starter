<template>
    <div id="wkwp-erp-addon-general-setting-tab" class="tab-container">
        <h2>GeneralTab Tab</h2>
        <div class="clear"></div>
    </div>
</template>

<script>
export default {
    name: 'GeneralTab',
}
</script>

<style>

</style>