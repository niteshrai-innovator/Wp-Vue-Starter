<template>
    <div id="wkwp-erp-addon-dashboard" class="tab-container">
        <h2>Dashboard</h2>
        <p>{{ message }}</p>
        <div class="clear"></div>
    </div>
</template>

<script>
export default {
    name: 'Dashboard',
    data() {
        return {
            message: 'Manage Dashboard From Here'
        }    
    }
}
</script>

<style>

</style>