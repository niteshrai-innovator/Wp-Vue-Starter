<template>
    <div id="wkwp-erp-addon-core-setting-tab" class="tab-container">
        <router-view name="tab"></router-view>
        <router-view></router-view>
    </div>
    
    
</template>

<script>
export default {
    name: 'Settings',
    
}
</script>

<style>

</style>