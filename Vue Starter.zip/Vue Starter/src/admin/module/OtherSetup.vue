<template>
    <div class="tab-container">
        <router-view name="tab"></router-view>
        <h2>Other Settings</h2>
        
        <div class="clear"></div>
    </div>
</template>

<script>
export default {
    name: 'OtherSetup',
}
</script>

<style>

</style>